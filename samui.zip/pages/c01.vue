<template>
  <div class="flex flex-col items-center justify-center min-h-screen text-center p-4 bg-blue-50">
    <h1 class="text-4xl font-bold mb-4">Welcome to our Boat Trips!</h1>
    
    <div v-for="(item, index) in images" :key="index">
      <!-- Image -->
      <img class="rounded-lg my-4" :src="item.src" alt="Boat trip image">

      <!-- Text (alternatively, you can put the descriptions in the images array and reference it with item.description) -->
      <p v-if="index === 0" class="mb-4">Description for first image</p>
      <p v-else-if="index === 1" class="mb-4">Description for second image</p>
      <p v-else-if="index === 2" class="mb-4">Description for third image</p>
      <p v-else-if="index === 3" class="mb-4">Description for fourth image</p>
      <p v-else-if="index === 4" class="mb-4">Description for fifth image</p>
      <p v-else-if="index === 5" class="mb-4">Description for sixth image</p>
      <!-- Add more <p> tags as necessary -->
    </div>

    <!-- Booking button -->
    <a href="http://link-to-booking.com" class="inline-block mt-4 px-6 py-3 text-lg font-semibold text-white bg-blue-600 rounded-lg">Book Now</a>
  </div>
</template>

<script setup>
import { ref } from 'vue';

const images = ref([
  { src: 'https://koh-samui.com/travelmain/phetchbuncha/img/Petbuncha%20package-1.jpg' },
  { src: 'https://koh-samui.com/travelmain/phetchbuncha/img/Petbuncha%20package-2.jpg' },
  { src: 'https://koh-samui.com/travelmain/phetchbuncha/img/Petbuncha%20package-3.jpg' },
  { src: 'https://koh-samui.com/travelmain/phetchbuncha/img/Petbuncha%20package-4.jpg' },
  { src: 'https://koh-samui.com/travelmain/phetchbuncha/img/Petbuncha%20package-5.jpg' },
  { src: 'https://koh-samui.com/travelmain/phetchbuncha/img/Petbuncha%20package-6.jpg' },
]);
</script>

<style scoped>
/* Add your styles here */
</style>
