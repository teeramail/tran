<template>
    <div>
      <AutoComplete
        v-model="selectedAgentLeader"
        :suggestions="filteredAgentLeaders"
        @complete="filterAgentLeaders"
        field="agentleader_nickname"
      />
    </div>
  </template>
  
  <script setup>
  import { ref, watchEffect } from 'vue';
  import AutoComplete from 'primevue/autocomplete';
  
  const selectedAgentLeader = ref(null);
  const agentLeaders = ref([]);
  const filteredAgentLeaders = ref([]);
  
  watchEffect(async () => {
    try {
      const response = await fetch('https://koh-samui.com:53005/agentleader');
      agentLeaders.value = await response.json();
    } catch (error) {
      console.error(error);
    }
  });
  
  const filterAgentLeaders = ({ query }) => {
    filteredAgentLeaders.value = agentLeaders.value.filter((agentLeader) =>
      agentLeader.agentleader_nickname.toLowerCase().startsWith(query.toLowerCase())
    );
  };
  </script>
  