const express = require("express");
const mongoose = require("mongoose");
const router = express.Router();

const { Schema } = mongoose;
const PaymentResultOne = require('./models/PaymentResultOne');


// Assuming you have the Agent schema and model defined
// const Agent = mongoose.model("Agent", agentSchema);

async function getJoinedData(req, res) {
  try {
    const orderno = req.query.orderno;

    const pipeline = [
      {
        $lookup: {
          from: "paymentresults",
          localField: "orderno",
          foreignField: "OrderNo",
          as: "paymentResult",
        },
      },
      {
        $unwind: {
          path: "$paymentResult",
          preserveNullAndEmptyArrays: true,
        },
      },
      
      
      {
        $addFields: {
          eventIdObjectId: { $toObjectId: "$eventId" }
        }
      },
      {
        $lookup: {
          from: "events",
          localField:"eventIdObjectId",
          foreignField: "_id",
          as: "event",
        },
      },
      {
        $unwind: {
          path: "$event",
          preserveNullAndEmptyArrays: true,
        },
      },

      {
        $addFields: {
          organizerIdObjectId: { $toObjectId: "$event.organizerId" }
        }
      },
      {
        $lookup: {
          from: "organizers",
          localField:"organizerIdObjectId",
          foreignField: "_id",
          as: "organizer",
        },
      },
      {
        $unwind: {
          path: "$organizer",
          preserveNullAndEmptyArrays: true,
        },
      },

      {
        $lookup: {
          from: "agenttools",
          localField: "idenger",
          foreignField: "EnterID",
          as: "agentTool",
        },
      },
      {
        $unwind: {
          path: "$agentTool",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "agents", 
          localField: "agentTool.agent_id",
          foreignField: "agent_id",
          as: "agent",
        },
      },
      {
        $unwind: {
          path: "$agent",
          preserveNullAndEmptyArrays: true,
        },
      },
      
      {
        $project: {
          ipaddress: 0,
          "paymentResult.TransactionId": 0,
          "paymentResult.OrderNo": 0,
          "paymentResult.CustomerId": 0,
          "paymentResult.BankCode": 0,
          "paymentResult.BankRefCode": 0,
          "paymentResult.CreditCardToken": 0,
          "paymentResult.Currency": 0,
          "paymentResult.CustomerName": 0,
          "paymentResult.CheckSum": 0,
        },
      },
    ];

    if (orderno) {
      pipeline.unshift({ $match: { orderno } });
    }

    const results = await PaymentResultOne.aggregate(pipeline);
    res.send(results);
  } catch (err) {
    res.status(500).send(err);
  }
}

router.get("/", getJoinedData);

// Update an existing payment result by ID
router.put("/:id", async (req, res) => {
  try {
    const paymentResultData = req.body;
    const paymentResultId = req.params.id;
    const updatedPaymentResult = await PaymentResultOne.findByIdAndUpdate(paymentResultId, paymentResultData, {
      new: true,
    });
    if (!updatedPaymentResult) {
      res.status(404).send("Payment result not found");
    } else {
      res.send(updatedPaymentResult);
    }
  } catch (err) {
    res.status(500).send(err);
  }
});

// In your router file (e.g., payresultone.js)

// Update usedatetime field by orderno
router.patch("/update-usedatetime", async (req, res) => {
  try {
    const { orderno } = req.body;
    const usedatetime = new Date(); // Set usedatetime to the current time
    const updatedResult = await PaymentResultOne.findOneAndUpdate(
      { orderno },
      { usedatetime },
      { new: true }
    );

    if (!updatedResult) {
      res.status(404).send("Order number not found");
    } else {
      res.send(updatedResult);
    }
  } catch (err) {
    res.status(500).send(err);
  }
});


// Add this line at the end of the file where getJoinedData is defined
module.exports.getJoinedData = getJoinedData;

module.exports = router;
