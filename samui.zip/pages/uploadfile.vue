<template>
    <div id="app">
      <ImageUpload />
      <!-- Your other components and content -->
    </div>
  </template>
  
  <script>
  import ImageUpload from '~/components/ImageSlider.vue';
  
  export default {
    components: {
      ImageUpload,
    },
  };
  </script>
  