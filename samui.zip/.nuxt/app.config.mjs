
import { defuFn } from 'C:/Users/cteer/vueproject/nuxt3/samui/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default /* #__PURE__ */ defuFn(inlineConfig)
