<template>
  <div>
    <Payment />
  </div>
</template>

<script>
import Payment from '/components/payment.vue'

export default {
  components: {
    Payment,
  },
}
</script>
